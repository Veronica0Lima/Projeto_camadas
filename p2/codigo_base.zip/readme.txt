No console python, 'pip install pyserial'
Verificar em gerenciador qual porta com esta o aduino 
Talvez mudar a porta usb. Ou tirar e por quando nao tem autorizacao :-\


